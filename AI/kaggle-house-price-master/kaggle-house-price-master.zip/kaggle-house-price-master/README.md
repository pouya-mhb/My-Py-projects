# kaggle-house-price
training model with python for kaggle competition house pricing.

### Score in Kaggle : 0.11792
